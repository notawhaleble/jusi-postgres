Jusi Postgres blob fixture
